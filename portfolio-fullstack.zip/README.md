
# Full Stack Portfolio

Frontend:
- React

Backend:
- Express

Database:
- MongoDB

Run:

server:
npm install
npm run dev

client:
npm install
npm start
